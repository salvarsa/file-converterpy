"""First module."""


def func1() -> int:
    """Return 1."""
    return 1
