"""Fake package."""
