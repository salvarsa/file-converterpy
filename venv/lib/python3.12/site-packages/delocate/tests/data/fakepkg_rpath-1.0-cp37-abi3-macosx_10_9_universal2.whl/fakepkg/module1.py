"""First module."""


def func1():
    """Return 1."""
    return 1
