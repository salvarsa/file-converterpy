"""Second module."""


def func2():
    """Return 2."""
    return 2


def func3():
    """Return 3."""
    return 3
